import './style.css'
import * as PIXI from 'pixi.js'
import { sound } from '@pixi/sound'


// Settings...

const constants = {
	resources: {
		textures: {
			bird: PIXI.Texture.from('images/bird.png'),
			pipe: PIXI.Texture.from('images/pipe.png'),
			floor: PIXI.Texture.from('images/floor.png'),
			background: PIXI.Texture.from('images/background-day.png'),
			digits: Array(10).fill(0).map((_, i) => PIXI.Texture.from(`images/${i}.png`)),
		},
		sounds: {
			hit: sound.add('hit', 'sounds/hit.ogg'),
			point: sound.add('point', 'sounds/point.ogg'),
			die: sound.add('die', 'sounds/die.ogg'),
			wing: sound.add('wing', 'sounds/wing.ogg'),
			swoosh: sound.add('swoosh', 'sounds/swoosh.ogg'),
		}	
	},
	sizes: {
		app: {
			width: 300,
			height: 500,
		},
		bird: {
			width: 34,
			height: 24,
		},
		pipe: {
			gap: 38,
			width: 64,
			scale: 0.35,
			minimumHeight: 90,
			maximumHeight: 300,
		},
		floor: {
			height: 105,
			width: 300,
			scale: 0.35,
		},
		digit: {
			width: 30,
		}
	},
	times: {
		pipeTimer: {
			start: 100,
			reset: 120,
		},
	},
	velocities: {
		pipe: {
			x: 1.5,
		},
		floor: {
			x: 1.5,
		},
		background: {
			x: 0.3,
		},
		bird: {
			default: {
				y: 0,
			},
			jump: {
				y: -4.8,
			},
			maximum: {
				y: 8,
			}
		},
	},
	accelerations: {
		bird: {
			default: {
				y: 0.3,
			},
		},
	},
	colors: {
		floor: 0xddd893,
	},
	contexts: {
		idle: 0,
		alive: 1,
		dead: 2,	
	},
	spritesheets: {
		get bird() {
			return {
				frames: {
					bird0: {
						frame: { x: sizes.bird.width*0, y: 0, w: sizes.bird.width, h: sizes.bird.height },
						sourceSize: { w: 32, h: 32 },
						spriteSourceSize: { x: 0, y: 0, w: sizes.bird.width, h: sizes.bird.height },
					},
					bird1: {
						frame: { x: sizes.bird.width*1, y: 0, w: sizes.bird.width, h: sizes.bird.height },
						sourceSize: { w: 32, h: 32 },
						spriteSourceSize: { x: 0, y: 0, w: sizes.bird.width, h: sizes.bird.height },
					},
					bird2: {
						frame: { x: sizes.bird.width*2, y: 0, w: sizes.bird.width, h: sizes.bird.height },
						sourceSize: { w: 32, h: 32 },
						spriteSourceSize: { x: 0, y: 0, w: sizes.bird.width, h: sizes.bird.height },
					},
				},
				meta: {
					image: 'images/bird-spritesheet.png',
					format: 'RGBA8888',
					size: { w: sizes.bird.width * 3, h: sizes.bird.height },
					scale: 1,
				},
				animations: {
					bird: ['bird0','bird1', 'bird2'] //array of frames by name
				},
			}
		},
	},
}


Object.assign(window, constants)




// Sprites...

const app = new PIXI.Application({ ...sizes.app })
document.body.append(app.view)


const pipeContainer = new PIXI.Container()


const backgroundSprite = new PIXI.TilingSprite(
	resources.textures.background,
	sizes.app.width,
	sizes.app.height,
)


const floorSprite = new PIXI.TilingSprite(
	resources.textures.floor,
	sizes.floor.width * (1 / sizes.floor.scale),
	sizes.floor.height,
)


floorSprite.scale.set(sizes.floor.scale)
floorSprite.position.set(0, sizes.app.height - sizes.floor.height)


const floorBottomSprite = new PIXI.Graphics();

floorBottomSprite.beginFill(colors.floor);
floorBottomSprite.drawRect(0, sizes.app.height - sizes.floor.height + 30, sizes.app.height, sizes.app.width);
floorBottomSprite.endFill();


const birdSpritesheet = new PIXI.Spritesheet(
        PIXI.BaseTexture.from(spritesheets.bird.meta.image),
        spritesheets.bird
)

await birdSpritesheet.parse()
const birdSprite = new PIXI.AnimatedSprite(birdSpritesheet.animations.bird)

birdSprite.animationSpeed = 0.14
birdSprite.play()
birdSprite.anchor.set(0.5)
birdSprite.position.set(sizes.app.width / 2, sizes.app.height / 2)


const scoreContainer = new PIXI.Container()

scoreContainer.position.y = 60


app.stage.addChild(backgroundSprite)
app.stage.addChild(birdSprite)
app.stage.addChild(pipeContainer)
app.stage.addChild(floorSprite)
app.stage.addChild(floorBottomSprite)
app.stage.addChild(scoreContainer)




// Game state...

const initialGameState = () => ({
	context: contexts.idle,
	pipeArray: [], // An array to store the pipes
	pipeTimer: { 
		time: times.pipeTimer.start 
	},
	nextPipeIndex: 0,
	score: {
		current: 0,
		top: 0, //localStorage.getItem('flappy-bird-score') ?? 0,
	},
	bird: {
		velocity: {
			y: velocities.bird.default.y,
		},
		acceleration: {
			y: accelerations.bird.default.y,
		},
	},
})


let gameState = initialGameState()




// Game loop...

app.ticker.add(delta => {


	if (gameState.context === contexts.alive) {
		gameState.pipeTimer.time -= 1


		if (gameState.pipeTimer.time <= 0) {
	
			gameState.pipeTimer.time = times.pipeTimer.reset

			// generate a pipe...

			const upperPipeSprite = new PIXI.Sprite(resources.textures.pipe)
			const lowerPipeSprite = new PIXI.Sprite(resources.textures.pipe)
		
			const x = sizes.app.width + sizes.pipe.width
			const y = sizes.app.height - sizes.floor.height - sizes.pipe.minimumHeight - Math.floor(Math.random() * (sizes.pipe.maximumHeight - sizes.pipe.minimumHeight))

			upperPipeSprite.scale.x = sizes.pipe.scale
			upperPipeSprite.scale.y = -sizes.pipe.scale
			upperPipeSprite.position.set(x, y - sizes.pipe.gap)

			lowerPipeSprite.scale.set(sizes.pipe.scale)
			lowerPipeSprite.position.set(x, y + sizes.pipe.gap)

			gameState.pipeArray.push([ upperPipeSprite, lowerPipeSprite ])
			pipeContainer.addChild(upperPipeSprite)
			pipeContainer.addChild(lowerPipeSprite)
		}

		// Update existing pipes...

		gameState.pipeArray.forEach(([ upperPipeSprite, lowerPipeSprite ]) => {
	
			upperPipeSprite.position.x -= velocities.pipe.x
			lowerPipeSprite.position.x -= velocities.pipe.x

			if (upperPipeSprite.position.x <= -sizes.pipe.width) {
				
				gameState.pipeArray.shift()
				gameState.nextPipeIndex -= 1
				pipeContainer.removeChild(upperPipeSprite)
				pipeContainer.removeChild(lowerPipeSprite)
			}
		})
	}


	if (gameState.context !== contexts.dead) {

		// Update background and floor...

		backgroundSprite.tilePosition.x -= velocities.background.x
		floorSprite.tilePosition.x -= velocities.floor.x / sizes.floor.scale
	}


	if (gameState.context === contexts.idle) {

		// Animate bird idle state...

		birdSprite.position.y += 0.5*Math.sin(Date.now() / 150)

	}


	if (gameState.context !== contexts.idle) {
		// Control bird in non-idle state...

	
		birdSprite.position.y = Math.min(sizes.app.height - sizes.floor.height, birdSprite.position.y + gameState.bird.velocity.y)
		gameState.bird.velocity.y = Math.min(velocities.bird.maximum.y, gameState.bird.velocity.y + gameState.bird.acceleration.y)


		// Collision with pipes or floor triggers a game over...
		// Otherwise, increase the score...


		if (gameState.context !== contexts.dead && (floorSprite.position.y - birdSprite.position.y < 10)) {
			sound.play('hit')
			stopGame()
		}


		if (gameState.context !== contexts.dead && gameState.pipeArray.length) {
			
			let [ nextUpperPipeSprite, nextLowerPipeSprite ] = gameState.pipeArray[gameState.nextPipeIndex]

			if (nextUpperPipeSprite.position.x < birdSprite.position.x - sizes.pipe.width ) {
				
				increaseScore()
				gameState.nextPipeIndex += 1
			}


			else if (nextUpperPipeSprite.position.x - birdSprite.position.x <= 5) {

				if (birdSprite.position.y <= nextUpperPipeSprite.position.y + 13 || birdSprite.position.y >= nextLowerPipeSprite.y - 13) {
					
					sound.play('hit')
					setTimeout(() => sound.play('die'), 200)
					stopGame()
				}
			}
		}
	}
})


// Functions...

function startGame() {

	gameState.context = contexts.alive
	birdSprite.play()
	showScore()
}


function restartGame() {

	gameState = initialGameState()
        //gameState.score.current = 0

        app.stage.removeChild(scoreContainer)
        app.stage.addChild(scoreContainer)

        pipeContainer.removeChildren()
        birdSprite.position.set(sizes.app.width / 2, sizes.app.height / 2)
}


function stopGame() {

	gameState.context = contexts.dead
	setTimeout(() => birdSprite.stop(), 100)

	document.querySelector('.flash').style.filter = 'opacity(0.9)'

	setTimeout(() => {
		document.querySelector('.flash').classList.toggle('vanish')
		document.querySelector('.flash').style.filter = 'opacity(0)'

	}, 100)

	
	setTimeout(() => {

		sound.play('swoosh')
		document.querySelector('.restart').classList.toggle('visible')
	
	}, 1000)
}


function increaseScore() {

	gameState.score.current += 1
	sound.play('point')
	showScore()
}


function showScore() {

	let value = gameState.score.current
        let i = 0

        scoreContainer.removeChildren()


        for (let digit of value.toString()) {
                digit = parseInt(digit)

                let digitSprite = new PIXI.Sprite(resources.textures.digits[digit])
                digitSprite.x = i

                scoreContainer.addChild(digitSprite)
                i += digitSprite.width + 2
        }

        scoreContainer.position.x = (sizes.app.width - scoreContainer.width) / 2
}


function birdJump() {
	gameState.bird.velocity.y = velocities.bird.jump.y
}


window.onkeypress = function() {

	if (gameState.context === contexts.idle) {
		startGame()
	}

	if (gameState.context === contexts.alive) {
		sound.play('wing')
		birdJump()
	}
}


document.querySelector('.restart img').onclick = function() {

	document.querySelector('.restart').classList.toggle('visible')
	restartGame()
}
